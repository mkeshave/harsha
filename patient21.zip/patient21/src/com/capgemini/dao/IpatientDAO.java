package com.capgemini.dao;
import com.capgemini.bean.Patientbean;
import com.capgemini.exception.PatientException;
public interface IpatientDAO {
	public String addPatientDetails(Patientbean customerbean) throws PatientException;
}





