package com.capgemini.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.capgemini.bean.Patientbean;
import com.capgemini.exception.PatientException;
import com.capgemini.util.DBConnection;

public class PatientDaoImpl implements IpatientDAO {
	
	Logger logger=Logger.getAnonymousLogger();
	
	public PatientDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addPatientDetails(Patientbean patientbean) throws PatientException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String patient_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, patientbean.getName());
			preparedStatement.setString(2, patientbean.getAge());
			preparedStatement.setString(3, patientbean.getPhoneNumber());
			preparedStatement.setString(4, patientbean.getdiseaseInterested());
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENT_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				patient_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Inserting patient details failed ");

			}
			else
			{
				logger.info("patient details added successfully:");
				return patient_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public String addCustomerDetails(Patientbean customerbean) throws PatientException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
