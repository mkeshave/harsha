package com.capgemini.service;

import com.capgemini.bean.Patientbean;
import com.capgemini.exception.PatientException;


public interface IPatientService {
	public String addPatientDetails(Patientbean patientbean) throws PatientException;
}
