package com.capgemini.bean;

import java.util.Date;

public class Patientbean {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((age == null) ? 0 : age.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		result = prime * result + ((diseaseInterested == null) ? 0 : diseaseInterested.hashCode());
		//result = prime * result + ((regDate == null) ? 0 : regDate.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patientbean other = (Patientbean) obj;
		if (age == null) {
			if (other.age != null)
				return false;
		} else if (!age.equals(other.age))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		if (diseaseInterested == null) {
			if (other.diseaseInterested != null)
				return false;
		} else if (!diseaseInterested.equals(other.diseaseInterested))
			return false;
		/*if (regDate == null) {
			if (other.regDate != null)
				return false;
		} else if (!regDate.equals(other.regDate))
			return false;*/
		return true;
	}



	private String name;
	private String age;
	private String phoneNumber;
	private String diseaseInterested;
	//private Date regDate;
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getAge() {
		return age;
	}



	public void setAge(String age) {
		this.age = age;
	}



	public String getPhoneNumber() {
		return phoneNumber;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	public String getdiseaseInterested() {
		return diseaseInterested;
	}



	public void setdiseaseInterested(String diseaseInterested) {
		this.diseaseInterested = diseaseInterested;
	}



	/*public Date getRegDate() {
		return regDate;
	}



	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
*/


	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Donor Details \n");
		sb.append("Name: " +name +"\n");
		sb.append("Age: " +age +"\n");
		sb.append("Phone Number: "+ phoneNumber +"\n");
		sb.append("Product Interested: "+ diseaseInterested +"\n");
	//sb.append("Reg Date: "+ regDate);
		return sb.toString();
	}
	
}
