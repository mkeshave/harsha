import java.sql.Connection;
import java.sql.DriverManager;

public class Test2 {

	public static void main(String[] args) {
		
		try{
		Class.forName("oracle.jdbc.OracleDriver");
		 
		Connection connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		System.out.println("connection ok");
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		

	}

}
